import requests
import json
import xml.etree.ElementTree as ET
from typing import Dict, Any, Optional, List, Tuple
import os
import re
from collections import Counter

class CeipalAPI:
    def __init__(self):
        self.base_url = "https://api.ceipal.com/v1"
        self.auth_token = None
   
    def authenticate(self, email: str, password: str, api_key: str) -> bool:
        """Authenticate with Ceipal API"""
        url = f"{self.base_url}/createAuthtoken"
        payload = {
            "email": email,
            "password": password,
            "api_key": api_key
        }
       
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
       
        try:
            response = requests.post(url, headers=headers, json=payload, timeout=30)
            response.raise_for_status()
           
            # Handle both JSON and XML responses
            content_type = response.headers.get('content-type', '').lower()
           
            if 'application/json' in content_type:
                data = response.json()
                self.auth_token = data.get('access_token')
            elif 'application/xml' in content_type or 'text/xml' in content_type:
                # Parse XML response
                root = ET.fromstring(response.text)
                access_token_elem = root.find('access_token')
                if access_token_elem is not None:
                    self.auth_token = access_token_elem.text
            else:
                # Try to auto-detect format
                try:
                    data = response.json()
                    self.auth_token = data.get('access_token')
                except json.JSONDecodeError:
                    try:
                        root = ET.fromstring(response.text)
                        access_token_elem = root.find('access_token')
                        if access_token_elem is not None:
                            self.auth_token = access_token_elem.text
                    except ET.ParseError:
                        print("Could not parse response as JSON or XML")
                        return False
           
            return self.auth_token is not None
           
        except Exception as e:
            print(f"Authentication error: {e}")
            return False

    def get_applicants(self, page: int = 1) -> Optional[Dict[str, Any]]:
        """Get applicants list with pagination"""
        if not self.auth_token:
            print("Not authenticated. Please authenticate first.")
            return None
       
        url = f"{self.base_url}/getApplicantsList"
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": f"Bearer {self.auth_token}"
        }
       
        params = {"page": page} if page > 1 else {}
       
        try:
            response = requests.get(url, headers=headers, params=params, timeout=30)
            response.raise_for_status()
           
            content_type = response.headers.get('content-type', '').lower()
           
            if 'application/json' in content_type:
                return response.json()
            elif 'application/xml' in content_type or 'text/xml' in content_type:
                return self._parse_xml_applicants(response.text)
            else:
                # Auto-detect
                try:
                    return response.json()
                except json.JSONDecodeError:
                    return self._parse_xml_applicants(response.text)
                   
        except Exception as e:
            print(f"Error fetching applicants: {e}")
            return None

    def get_all_applicants(self, max_pages: int = 10) -> List[Dict[str, Any]]:
        """Get all applicants across multiple pages"""
        all_applicants = []
        page = 1
       
        while True:
            print(f"Fetching applicants page {page}...")
            page_data = self.get_applicants(page)
           
            if not page_data or 'results' not in page_data:
                break
           
            all_applicants.extend(page_data['results'])
           
            # Check if there's a next page or if we've reached the limit
            if not page_data.get('next') or page >= max_pages:
                break
           
            page += 1
       
        return all_applicants

    def _parse_xml_applicants(self, xml_text: str) -> Dict[str, Any]:
        """Parse XML applicants data into dictionary format"""
        try:
            root = ET.fromstring(xml_text)
            result = {'results': []}
           
            # Look for results
            results_elem = root.find('results')
            if results_elem is not None:
                for item in results_elem.findall('item'):
                    applicant = {}
                    for child in item:
                        applicant[child.tag] = child.text
                    result['results'].append(applicant)
           
            # Add other metadata if available
            for elem in root:
                if elem.tag != 'results':
                    result[elem.tag] = elem.text
           
            return result
           
        except ET.ParseError as e:
            print(f"XML parsing error: {e}")
            return {'results': []}

    def extract_skills_from_applicants(self, applicants: List[Dict[str, Any]]) -> Dict[str, List[str]]:
        """Extract common skills from applicants grouped by job title"""
        job_skills = {}
        
        for applicant in applicants:
            job_title = applicant.get('job_title', 'Unknown').strip()
            skills_text = applicant.get('skills', '')
            
            if not job_title or not skills_text:
                continue
                
            # Extract individual skills from the skills text
            skills = self._parse_skills(skills_text)
            
            if job_title not in job_skills:
                job_skills[job_title] = []
            
            job_skills[job_title].extend(skills)
        
        # Get most common skills for each job title
        common_skills_by_job = {}
        for job_title, skills_list in job_skills.items():
            skill_counter = Counter(skills_list)
            # Get top 10 most common skills for this job title
            common_skills = [skill for skill, count in skill_counter.most_common(10)]
            common_skills_by_job[job_title] = common_skills
        
        return common_skills_by_job

    def _parse_skills(self, skills_text: str) -> List[str]:
        """Parse skills text into individual skills"""
        # Split by common delimiters
        skills = re.split(r',|\|/|;', skills_text)
        
        # Clean up each skill
        cleaned_skills = []
        for skill in skills:
            skill = skill.strip()
            if skill and len(skill) > 1:  # Skip empty and very short skills
                cleaned_skills.append(skill)
        
        return cleaned_skills

    def search_applicants_by_skills(self, skills_keywords: List[str], applicants: List[Dict[str, Any]]) -> List[Tuple[Dict[str, Any], List[str]]]:
        """Search applicants by skills keywords and return applicants with matched skills"""
        matched_applicants = []
       
        for applicant in applicants:
            skills = applicant.get('skills', '').lower()
            matched_skills = []
            
            for keyword in skills_keywords:
                if keyword.lower() in skills:
                    matched_skills.append(keyword)
            
            if matched_skills:
                matched_applicants.append((applicant, matched_skills))
       
        return matched_applicants

    def download_resume(self, resume_url: str, applicant_name: str, job_title: str = "", download_dir: str = "resumes") -> Optional[str]:
        """Download a resume from the provided URL"""
        if not resume_url or resume_url == "N/A":
            print(f"No resume URL for {applicant_name}")
            return None
            
        if not self.auth_token:
            print("Not authenticated. Please authenticate first.")
            return None
            
        # Create download directory if it doesn't exist
        os.makedirs(download_dir, exist_ok=True)
        
        # Clean up the applicant name and job title for filename
        clean_name = "".join(c for c in applicant_name if c.isalnum() or c in (' ', '-', '_')).rstrip()
        clean_job = "".join(c for c in job_title if c.isalnum() or c in (' ', '-', '_')).rstrip() if job_title else ""
        
        file_extension = self._get_file_extension(resume_url)
        
        if clean_job:
            filename = f"{clean_name} - {clean_job}{file_extension}"
        else:
            filename = f"{clean_name}{file_extension}"
            
        filepath = os.path.join(download_dir, filename)
        
        headers = {
            "Authorization": f"Bearer {self.auth_token}"
        }
        
        try:
            print(f"Downloading resume for {applicant_name}...")
            response = requests.get(resume_url, headers=headers, timeout=30)
            response.raise_for_status()
            
            # Save the file
            with open(filepath, 'wb') as f:
                f.write(response.content)
                
            print(f"Resume saved to {filepath}")
            return filepath
            
        except Exception as e:
            print(f"Error downloading resume for {applicant_name}: {e}")
            return None
            
    def _get_file_extension(self, url: str) -> str:
        """Try to determine file extension from URL"""
        # Check common extensions in the URL
        common_extensions = ['.pdf', '.doc', '.docx', '.txt', '.rtf']
        for ext in common_extensions:
            if ext in url.lower():
                return ext
                
        # Default to .pdf if we can't determine
        return '.pdf'

def main():
    # Configuration
    CREDENTIALS = {
        "email": "support@innosoul.com",
        "password": "Db2@Admin1",
        "api_key": "226113748caee4447d14c2ddc0fbd12f0de8153d90b52547f2"
    }
   
    print("=== Ceipal Applicants Fetcher ===")
   
    # Initialize API client
    api = CeipalAPI()
   
    # Authenticate
    print("Authenticating...")
    if not api.authenticate(**CREDENTIALS):
        print("Authentication failed!")
        return
   
    print("Authentication successful!")
   
    # Get applicants
    print("Fetching applicants...")
    applicants_data = api.get_applicants()
   
    if not applicants_data:
        print("No applicants data received")
        return
   
    applicants = applicants_data.get('results', [])
    total_count = applicants_data.get('count', 0)
   
    print(f"\nFound {len(applicants)} applicants (Total in system: {total_count}):")
   
    # Automatically extract common skills by job title
    print("\n=== Analyzing skills by job title ===")
    job_skills = api.extract_skills_from_applicants(applicants)
    
    # Process each job title automatically
    for job_title, required_skills in job_skills.items():
        print(f"\n=== Processing Job: {job_title} ===")
        print(f"Automatically detected required skills: {', '.join(required_skills)}")
        
        # Find applicants whose job title matches
        job_applicants = [app for app in applicants if job_title.lower() in app.get('job_title', '').lower()]
        
        if not job_applicants:
            print(f"No applicants found for job title: {job_title}")
            continue
            
        print(f"Found {len(job_applicants)} applicants with job title: {job_title}")
        
        # Search for applicants with the required skills
        matched_applicants = api.search_applicants_by_skills(required_skills, job_applicants)
        
        print(f"Found {len(matched_applicants)} applicants with matching skills for {job_title}")
        
        # Download resumes for matched applicants
        for applicant, matched_skills in matched_applicants:
            applicant_name = f"{applicant.get('firstname', '')} {applicant.get('lastname', '')}"
            print(f"\nProcessing {applicant_name}:")
            print(f"Matched Skills: {', '.join(matched_skills)}")
            
            # Download resume
            resume_url = applicant.get('resume_path')
            if resume_url:
                api.download_resume(resume_url, applicant_name, job_title)
            else:
                print(f"No resume URL available for {applicant_name}")
    
    # Save all applicants data to file
    try:
        with open('ceipal_applicants.json', 'w', encoding='utf-8') as f:
            json.dump(applicants_data, f, indent=2, ensure_ascii=False)
        print("\nData saved to 'ceipal_applicants.json'")
        
        # Save job skills analysis
        with open('job_skills_analysis.json', 'w', encoding='utf-8') as f:
            json.dump(job_skills, f, indent=2, ensure_ascii=False)
        print("Job skills analysis saved to 'job_skills_analysis.json'")
        
    except Exception as e:
        print(f"Error saving file: {e}")

if __name__ == "__main__":
    main()