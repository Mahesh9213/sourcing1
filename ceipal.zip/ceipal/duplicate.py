from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import time
import json
import csv
import os
import traceback

class CeipalCandidateSearch:
    def __init__(self):
        self.driver = None
        self.wait = None
        self.resume_folder = "resume_folder"
        
    def setup_driver(self):
        """Setup Chrome WebDriver with appropriate options"""
        chrome_options = Options()
        chrome_options.add_argument("--start-maximized")
        chrome_options.add_argument("--disable-notifications")
        chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
        chrome_options.add_experimental_option('useAutomationExtension', False)
        
        # Set download preferences
        os.makedirs(self.resume_folder, exist_ok=True)
        download_dir = os.path.abspath(self.resume_folder)
        chrome_options.add_experimental_option("prefs", {
            "download.default_directory": download_dir,
            "download.prompt_for_download": False,
            "download.directory_upgrade": True,
            "safebrowsing.enabled": True
        })
        
        try:
            self.driver = webdriver.Chrome(options=chrome_options)
            self.wait = WebDriverWait(self.driver, 20)
            return True
        except Exception as e:
            print(f"Error setting up WebDriver: {e}")
            return False
    
    def login_to_ceipal(self, username, password, ceipal_url):
        """Login to Ceipal ATS with the specific login page structure"""
        print("🌐 Logging into Ceipal ATS...")
        
        try:
            self.driver.get(ceipal_url)
            time.sleep(3)
            
            # Wait for page to load completely
            self.wait.until(EC.presence_of_element_located((By.TAG_NAME, "body")))
            
            # Take screenshot to see what we're working with
            self.driver.save_screenshot("ceipal_login_page.png")
            print("📸 Saved screenshot of login page")
            
            # Try to find username field - look for various possible selectors
            username_selectors = [
                "input[type='text'][name*='user']",
                "input[type='text'][name*='login']",
                "input[type='text'][id*='user']",
                "input[type='text'][id*='login']",
                "input[placeholder*='user']",
                "input[placeholder*='login']",
                "#username",
                "#userName",
                "#login",
                "#email"
            ]
            
            username_field = None
            for selector in username_selectors:
                try:
                    username_field = self.driver.find_element(By.CSS_SELECTOR, selector)
                    print(f"✅ Found username field with selector: {selector}")
                    break
                except:
                    continue
            
            if not username_field:
                # Try to find by label text
                try:
                    user_label = self.driver.find_element(By.XPATH, "//label[contains(text(), 'User') or contains(text(), 'Login')]")
                    username_field = self.driver.find_element(By.ID, user_label.get_attribute("for"))
                except:
                    # Last resort: try any text input that's not password
                    try:
                        username_field = self.driver.find_element(By.XPATH, "//input[@type='text' and not(@type='password')]")
                    except:
                        print("❌ Could not find username field")
                        return False
            
            username_field.clear()
            username_field.send_keys(username)
            print("✅ Filled username")
            
            # Find password field
            password_selectors = [
                "input[type='password']",
                "input[name*='pass']",
                "input[id*='pass']",
                "#password",
                "#pass"
            ]
            
            password_field = None
            for selector in password_selectors:
                try:
                    password_field = self.driver.find_element(By.CSS_SELECTOR, selector)
                    print(f"✅ Found password field with selector: {selector}")
                    break
                except:
                    continue
            
            if not password_field:
                # Try to find by label text
                try:
                    pass_label = self.driver.find_element(By.XPATH, "//label[contains(text(), 'Pass')]")
                    password_field = self.driver.find_element(By.ID, pass_label.get_attribute("for"))
                except:
                    # Last resort: try any password input
                    try:
                        password_field = self.driver.find_element(By.XPATH, "//input[@type='password']")
                    except:
                        print("❌ Could not find password field")
                        return False
            
            password_field.clear()
            password_field.send_keys(password)
            print("✅ Filled password")
            
            # Find and click login button
            login_buttons = self.driver.find_elements(By.XPATH, "//button[contains(text(), 'Sign In') or contains(text(), 'Login') or contains(text(), 'Log In')]")
            if not login_buttons:
                login_buttons = self.driver.find_elements(By.CSS_SELECTOR, "input[type='submit'][value*='Sign'], input[type='submit'][value*='Log']")
            
            if login_buttons:
                login_buttons[0].click()
                print("✅ Clicked login button")
            else:
                # Try pressing Enter
                password_field.send_keys(Keys.RETURN)
                print("✅ Pressed Enter to login")
            
            # Wait for login to complete - look for dashboard elements
            try:
                self.wait.until(EC.presence_of_element_located((By.XPATH, "//*[contains(text(), 'Dashboard') or contains(text(), 'Candidates') or contains(text(), 'Jobs')]")))
                print("✅ Login successful!")
                return True
            except TimeoutException:
                # Check if login failed
                try:
                    error_msg = self.driver.find_element(By.XPATH, "//*[contains(text(), 'Invalid') or contains(text(), 'Error') or contains(text(), 'incorrect')]")
                    print(f"❌ Login failed: {error_msg.text}")
                    return False
                except:
                    print("⚠️  Login status unclear - proceeding anyway")
                    return True
                    
        except Exception as e:
            print(f"❌ Login failed: {e}")
            return False

    def click_quick_links(self):
        """Click on the Quick Links element using the specific class and attributes"""
        print("🔗 Clicking Quick Links...")
        
        try:
            # Wait for the page to fully load after login
            time.sleep(3)
            
            # Try to find the Quick Links element using the specific class and attributes
            quick_links_selectors = [
                "span.svg-i.n-listApps[data-toggle='tooltip'][data-placement='bottom'][data-original-title='Quick Links']",
                "span.n-listApps",
                "span[data-original-title='Quick Links']",
                "span.svg-i[data-original-title='Quick Links']"
            ]
            
            quick_links_element = None
            for selector in quick_links_selectors:
                try:
                    quick_links_element = self.wait.until(
                        EC.element_to_be_clickable((By.CSS_SELECTOR, selector))
                    )
                    print(f"✅ Found Quick Links with selector: {selector}")
                    break
                except:
                    continue
            
            if not quick_links_element:
                print("❌ Could not find Quick Links element")
                return False
            
            # Click on the Quick Links element
            quick_links_element.click()
            print("✅ Clicked Quick Links")
            
            # Wait for the Quick Links menu to appear
            time.sleep(2)
            
            # Take screenshot after clicking Quick Links
            self.driver.save_screenshot("after_quick_links.png")
            print("📸 Saved screenshot after clicking Quick Links")
            
            return True
            
        except Exception as e:
            print(f"❌ Failed to click Quick Links: {e}")
            return False

    def navigate_to_advanced_search(self):
        """Navigate to Advanced Search from Quick Links menu"""
        print("🔍 Navigating to Advanced Search...")
        
        try:
            # Wait for the Quick Links menu to be fully expanded
            time.sleep(2)
            
            # Try to find the Advanced Search link using the specific HTML structure
            advanced_search_selectors = [
                "a[href*='/applicant_profiles/applicant_search'][title='Advanced Search']",
                "a[href*='applicant_search']",
                "a[title='Advanced Search']",
                "//a[contains(@href, 'applicant_search') and contains(@title, 'Advanced Search')]",
                "//a[.//span[contains(text(), 'Advanced Search')]]",
                "//span[contains(text(), 'Advanced Search')]"
            ]
            
            advanced_search_element = None
            for selector in advanced_search_selectors:
                try:
                    if selector.startswith("//"):
                        advanced_search_element = self.driver.find_element(By.XPATH, selector)
                    else:
                        advanced_search_element = self.driver.find_element(By.CSS_SELECTOR, selector)
                    
                    print(f"✅ Found Advanced Search with selector: {selector}")
                    break
                except:
                    continue
            
            if not advanced_search_element:
                print("❌ Could not find Advanced Search element")
                # Take screenshot to help debug
                self.driver.save_screenshot("quick_links_menu.png")
                print("📸 Saved screenshot of Quick Links menu for debugging")
                return False
            
            # Click on the Advanced Search element
            advanced_search_element.click()
            print("✅ Clicked Advanced Search")
            
            # Wait for the Advanced Search page to load
            time.sleep(5)
            
            # Verify we're on the Advanced Search page
            try:
                self.wait.until(EC.presence_of_element_located((By.XPATH, "//*[contains(text(), 'Advanced Search') or contains(text(), 'Applicant Search')]")))
                print("✅ Successfully navigated to Advanced Search page")
                
                # Take screenshot of the Advanced Search page
                self.driver.save_screenshot("advanced_search_page.png")
                print("📸 Saved screenshot of Advanced Search page")
                
                return True
            except TimeoutException:
                print("⚠️  May not be on Advanced Search page, but navigation completed")
                return True
                
        except Exception as e:
            print(f"❌ Failed to navigate to Advanced Search: {e}")
            return False

    def navigate_to_dice_job_board(self):
        """Navigate to Dice job board from Advanced Search page"""
        print("🎯 Navigating to Dice job board...")
        
        try:
            # Wait for the Advanced Search page to fully load
            time.sleep(3)
            
            # Try to find the Dice job board link using the specific HTML structure
            dice_selectors = [
                "a.job-board-link-new[rel_div='dice']",
                "a[rel_div='dice']",
                "a[job_board_type='7']",
                "//a[contains(@class, 'job-board-link-new') and contains(text(), 'Dice')]",
                "//a[contains(text(), 'Dice') and @rel_div='dice']"
            ]
            
            dice_element = None
            for selector in dice_selectors:
                try:
                    if selector.startswith("//"):
                        dice_element = self.driver.find_element(By.XPATH, selector)
                    else:
                        dice_element = self.driver.find_element(By.CSS_SELECTOR, selector)
                    
                    print(f"✅ Found Dice link with selector: {selector}")
                    break
                except:
                    continue
            
            if not dice_element:
                print("❌ Could not find Dice job board link")
                # Take screenshot to help debug
                self.driver.save_screenshot("advanced_search_page_debug.png")
                print("📸 Saved screenshot of Advanced Search page for debugging")
                return False
            
            # Click on the Dice element
            dice_element.click()
            print("✅ Clicked Dice job board link")
            
            # Wait for the Dice search interface to load
            time.sleep(5)
            
            # Take screenshot after navigating to Dice
            self.driver.save_screenshot("dice_job_board.png")
            print("📸 Saved screenshot of Dice job board")
            
            return True
            
        except Exception as e:
            print(f"❌ Failed to navigate to Dice job board: {e}")
            return False

    def _create_boolean_search_string(self, skills, location="Dimondale, MI"):
        """Create a Boolean search string for Dice with proper syntax, including location"""
        print("🔧 Creating Boolean search string for Dice...")
        
        # Dice Boolean operators: AND, OR, NOT, parentheses, quotes for exact phrases
        boolean_parts = []
        
        # 1. Primary role (required)
        boolean_parts.append('("Java Developer" OR "Full Stack Developer" OR "Full-Stack Java Developer" OR "Java Full Stack")')
        
        # 2. Backend frameworks and ORM
        boolean_parts.append('("Spring Boot" OR Spring OR "Spring Framework" OR Hibernate OR JPA OR "Java Persistence")')
        
        # 3. Databases
        boolean_parts.append('(Oracle OR "NoSQL" OR MongoDB OR Cassandra OR "relational database")')
        
        # 4. Frontend technologies
        boolean_parts.append('(Angular OR React OR "JavaScript framework")')
        
        # 5. APIs and data formats
        boolean_parts.append('("RESTful APIs" OR REST OR "REST API" OR JSON)')
        
        # 6. DevOps and CI/CD tools
        boolean_parts.append('(Git OR Jenkins OR Docker OR Kubernetes OR K8s OR Maven)')
        
        # 7. Practices and methodologies
        boolean_parts.append('(TDD OR "Test Driven Development" OR JWT OR "Agile" OR Scrum OR Kanban OR SDLC)')
        
        # 8. Experience level (15+ years, 5 pages resume indicating senior level)
        boolean_parts.append('("15 years" OR "15+ years" OR "senior" OR "lead" OR "principal" OR "architect")')
        
        # 9. Location (Dimondale, MI or nearby areas)
        boolean_parts.append('("Dimondale, MI" OR Dimondale OR "Lansing, MI" OR Michigan OR MI OR "state of Michigan")')
        
        # Combine all parts with AND operator
        boolean_query = " AND ".join(boolean_parts)
        
        print(f"🔍 Final Boolean query: {boolean_query}")
        return boolean_query

    def _create_simple_boolean_search(self, skills):
        """Create a simpler Boolean search string"""
        # Convert skills to proper Boolean format
        boolean_skills = []
        
        for skill in skills:
            # If skill has multiple words, wrap in quotes for exact match
            if ' ' in skill and len(skill) > 3:
                boolean_skills.append(f'"{skill}"')
            else:
                boolean_skills.append(skill)
        
        # Join with AND operator (Dice uses AND by default between terms)
        return " AND ".join(boolean_skills)

    def perform_dice_search(self, skills, use_advanced_boolean=True):
        """Perform a Boolean search on the Dice job board with location"""
        print("🎯 Performing Dice Boolean search...")
        
        try:
            # Take screenshot before searching
            self.driver.save_screenshot("before_dice_search.png")
            
            # Wait for Dice interface to load completely
            time.sleep(3)
            
            # Try to find search fields in Dice interface
            search_field_selectors = [
                "input[type='text']",
                "textarea",
                "input[name*='skill']",
                "input[placeholder*='skill']",
                "input[name*='keyword']",
                "input[placeholder*='keyword']",
                "input[name*='search']",
                "#search",
                "#keywords",
                "#skills",
                "input[type='search']",
                ".search-input",
                ".keyword-input"
            ]
            
            search_field = None
            for selector in search_field_selectors:
                try:
                    elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                    for element in elements:
                        if element.is_displayed() and element.is_enabled() and element.size['width'] > 100:
                            search_field = element
                            break
                    if search_field:
                        print(f"✅ Found search field with selector: {selector}")
                        break
                except:
                    continue
            
            if not search_field:
                print("❌ Could not find search field in Dice interface")
                # Try one more approach - look for the largest text input
                try:
                    all_inputs = self.driver.find_elements(By.TAG_NAME, "input")
                    text_inputs = [inp for inp in all_inputs if inp.get_attribute("type") in ["text", "search"] and inp.is_displayed()]
                    if text_inputs:
                        # Find the largest input field (likely the search box)
                        text_inputs.sort(key=lambda x: x.size['width'], reverse=True)
                        search_field = text_inputs[0]
                        print("✅ Found search field by size detection")
                except:
                    pass
            
            if not search_field:
                print("❌ Could not find search field after all attempts")
                return False
        
            # Clear the search field
            search_field.clear()
            time.sleep(1)
            
            # Create Boolean search string
            if use_advanced_boolean:
                boolean_search = self._create_boolean_search_string(skills)
            else:
                boolean_search = self._create_simple_boolean_search(skills)
            
            # Enter the search query
            search_field.send_keys(boolean_search)
            print(f"✅ Filled Boolean search: {boolean_search}")
            
            # Fill the location field
            try:
                location_field = self.driver.find_element(By.ID, "FilterLocationSearch")
                location_field.clear()
                location_field.send_keys("Dimondale, MI")
                print("✅ Filled location field with: Dimondale, MI")
            except Exception as e:
                print(f"⚠️ Could not find or fill location field (FilterLocationSearch): {e}")
                # Proceed with search even if location field fails, as Boolean query includes location
            
            # Try to find and click search button
            search_buttons = self.driver.find_elements(By.XPATH, 
                "//button[contains(text(), 'Search') or contains(text(), 'Find') or contains(text(), 'Submit') or contains(@class, 'search')]")
            
            if not search_buttons:
                search_buttons = self.driver.find_elements(By.CSS_SELECTOR, 
                    "input[type='submit'][value*='Search'], input[type='submit'][value*='Find'], input[type='submit'][value*='Submit'], button[type='submit']")
            
            if search_buttons:
                for button in search_buttons:
                    if button.is_displayed() and button.is_enabled():
                        button.click()
                        print("✅ Clicked search button")
                        break
            else:
                # Press Enter as last resort
                search_field.send_keys(Keys.RETURN)
                print("✅ Pressed Enter to search")
            
            # Wait for results with longer timeout
            print("⏳ Waiting for search results...")
            time.sleep(8)
            
            # Take screenshot of results
            self.driver.save_screenshot("dice_search_results.png")
            print("📸 Saved screenshot of Dice search results")
            
            # Check if we got results
            try:
                results_indicators = self.driver.find_elements(By.XPATH, 
                    "//*[contains(text(), 'result') or contains(text(), 'candidate') or contains(text(), 'profile')]")
                if results_indicators:
                    print(f"📊 Search completed. Results indicator: {results_indicators[0].text}")
            except:
                print("ℹ️  Results status unclear - proceeding with extraction")
            
            return True
            
        except Exception as e:
            print(f"❌ Dice search failed: {e}")
            traceback.print_exc()
            return False

    def extract_search_results(self):
        """Extract top 10 candidate profiles from the search page, open each, extract details, download resume"""
        print("📊 Extracting top 10 candidate profiles...")
        
        candidates_data = []  # List to hold name, email, phone
        
        try:
            # Wait a bit more for results to stabilize
            time.sleep(3)
            
            # Look for candidate profile containers - common Dice selectors
            profile_selectors = [
                "div.candidate-profile",
                "div.profile-card",
                "div.resume-card",
                "div.search-result",
                "li.candidate",
                "tr.candidate-row",
                "div[data-type='candidate']",
                "div.profile",
                ".candidate-container",
                ".profile-container",
                ".search-result-item",
                ".result-item"
            ]
            
            profile_elements = []
            
            # Try multiple selectors to find profile elements
            for selector in profile_selectors:
                try:
                    elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                    if elements and len(elements) > 0:
                        print(f"✅ Found {len(elements)} profile elements with selector: {selector}")
                        profile_elements = elements
                        break
                except Exception as e:
                    print(f"❌ Error with selector {selector}: {e}")
                    continue
            
            # If no specific profile containers found, try to find any repeating elements that might be profiles
            if not profile_elements:
                print("⚠️  No specific profile containers found, looking for any repeating div elements...")
                try:
                    all_divs = self.driver.find_elements(By.CSS_SELECTOR, "div")
                    # Filter for divs that might be profiles (have reasonable size and content)
                    candidate_divs = []
                    for div in all_divs:
                        try:
                            if (div.is_displayed() and 
                                div.size['height'] > 100 and 
                                div.size['width'] > 300 and
                                len(div.text.strip()) > 50):
                                candidate_divs.append(div)
                        except:
                            continue
                    
                    if candidate_divs:
                        print(f"✅ Found {len(candidate_divs)} potential profile divs")
                        profile_elements = candidate_divs[:10]  # Take top 10
                except Exception as e:
                    print(f"❌ Error finding div elements: {e}")
            
            # Process each profile element (limit to 15)
            for i, element in enumerate(profile_elements[:15]):
                try:
                    # First, extract basic data from list view
                    basic_data = self._extract_profile_data(element, i+1)
                    
                    if not basic_data or not basic_data.get('name'):
                        print(f"⚠️  Skipping profile {i+1} due to missing basic data")
                        continue
                    
                    # Find and click the profile link to open detailed view
                    profile_link = self._find_profile_link(element)
                    if not profile_link:
                        print(f"⚠️  Could not find profile link for {basic_data['name']}, skipping")
                        continue
                    
                    profile_link.click()
                    print(f"✅ Opened profile for {basic_data['name']}")
                    time.sleep(5)  # Wait for profile page to load
                    
                    # Extract detailed contact info
                    email, phone = self._extract_contact_info()
                    
                    # Download resume
                    self._download_resume(basic_data['name'])
                    
                    # Collect data
                    candidates_data.append({
                        'name': basic_data['name'],
                        'email': email,
                        'phone': phone
                    })
                    
                    # Navigate back to search results
                    self.driver.back()
                    time.sleep(3)  # Wait for results page to reload
                    
                    print(f"✅ Processed profile {i+1}: {basic_data['name']}")
                    
                except Exception as e:
                    print(f"❌ Error processing profile {i+1}: {e}")
                    traceback.print_exc()
                    # Try to go back if stuck
                    try:
                        self.driver.back()
                        time.sleep(3)
                    except:
                        pass
                    continue
            
            # If no data extracted, fallback
            if not candidates_data:
                print("❌ No profiles could be processed")
            
            return candidates_data
            
        except Exception as e:
            print(f"❌ Profile extraction failed: {e}")
            traceback.print_exc()
            return []

    def _find_profile_link(self, element):
        """Find the clickable link to open the candidate profile"""
        link_selectors = [
            "a[href*='profile']", "a[href*='candidate']", "a[href*='applicant']",
            "a.candidate-name", "a.profile-name", "a.name-link",
            "a.view-profile", "button.view-profile",
            "a[href*='view']"
        ]
        
        for selector in link_selectors:
            try:
                link = element.find_element(By.CSS_SELECTOR, selector)
                if link.is_displayed() and link.is_enabled():
                    return link
            except:
                continue
        
        # Last resort: if name is clickable
        try:
            name_elements = element.find_elements(By.CSS_SELECTOR, "h2, h3, h4, .name")
            for name_el in name_elements:
                if name_el.tag_name == 'a' or name_el.find_elements(By.TAG_NAME, "a"):
                    return name_el if name_el.tag_name == 'a' else name_el.find_element(By.TAG_NAME, "a")
        except:
            pass
        
        # Additional attempt based on screenshot: the name is likely an a tag with text
        try:
            name_link = element.find_element(By.XPATH, ".//a[contains(., 'Full Stack Developer')]")
            return name_link
        except:
            pass
        
        return None

    def _extract_profile_data(self, element, profile_number):
        """Extract data from a single profile element"""
        try:
            # Get the entire text content first
            full_text = element.text.strip()
            
            # Extract name
            name_selectors = [
                "h2", "h3", "h4", 
                ".candidate-name", ".profile-name", ".name",
                "[data-field='name']", "[itemprop='name']",
                "strong", "b"  # Name might be in bold
            ]
            name = "Unknown"
            for selector in name_selectors:
                try:
                    name_element = element.find_element(By.CSS_SELECTOR, selector)
                    if name_element.text.strip():
                        name = name_element.text.strip()
                        # Clean up name (remove extra whitespace, special characters)
                        name = ' '.join(name.split())
                        break
                except:
                    continue
            
            # Extract title/position
            title_selectors = [
                ".candidate-title", ".profile-title", ".title",
                ".job-title", "[data-field='title']", "[itemprop='title']",
                ".position", ".current-role"
            ]
            title = "Java Full Stack Developer"  # Default
            for selector in title_selectors:
                try:
                    title_element = element.find_element(By.CSS_SELECTOR, selector)
                    if title_element.text.strip():
                        title = title_element.text.strip()
                        break
                except:
                    continue
            
            # Extract location
            location_selectors = [
                ".location", ".candidate-location", ".profile-location",
                "[data-field='location']", "[itemprop='address']",
                ".address", ".city-state"
            ]
            location = "Location not specified"
            for selector in location_selectors:
                try:
                    location_element = element.find_element(By.CSS_SELECTOR, selector)
                    if location_element.text.strip():
                        location = location_element.text.strip()
                        break
                except:
                    continue
            
            # Extract skills - look for skill lists, keywords, or tech terms
            skills_selectors = [
                ".skills", ".candidate-skills", ".profile-skills",
                "[data-field='skills']", ".keywords",
                ".technologies", ".expertise"
            ]
            skills = "Skills not specified"
            for selector in skills_selectors:
                try:
                    skills_element = element.find_element(By.CSS_SELECTOR, selector)
                    if skills_element.text.strip():
                        skills = skills_element.text.strip()
                        break
                except:
                    continue
            
            # If skills still not found, try to extract from full text
            if skills == "Skills not specified":
                # Look for common tech terms in the text
                tech_keywords = ["Java", "Spring Boot", "Spring", "Oracle", "Hibernate", "JPA", "Angular", "React", 
                                 "RESTful APIs", "JSON", "NoSQL", "Git", "Jenkins", "Docker", "Kubernetes", 
                                 "Maven", "TDD", "JWT", "Agile", "Scrum", "Kanban", "SDLC"]
                found_skills = []
                for keyword in tech_keywords:
                    if keyword.lower() in full_text.lower():
                        found_skills.append(keyword)
                if found_skills:
                    skills = ", ".join(found_skills)
            
            # Extract summary/description
            summary_selectors = [
                ".summary", ".candidate-summary", ".profile-summary",
                "[data-field='summary']", ".description",
                ".bio", ".about"
            ]
            summary = full_text[:300] + "..." if len(full_text) > 300 else full_text
            for selector in summary_selectors:
                try:
                    summary_element = element.find_element(By.CSS_SELECTOR, selector)
                    if summary_element.text.strip():
                        summary_text = summary_element.text.strip()
                        summary = summary_text[:300] + "..." if len(summary_text) > 300 else summary_text
                        break
                except:
                    continue
            
            return {
                'profile_number': profile_number,
                'name': name,
                'title': title,
                'location': location,
                'skills': skills,
                'summary': summary
            }
            
        except Exception as e:
            print(f"Error extracting profile data: {e}")
            return None

    def _extract_contact_info(self):
        """Extract email and phone from the detailed profile page"""
        email = "Not found"
        phone = "Not found"
        
        # Email selectors
        email_selectors = [
            "[type='email']", ".email", ".contact-email", "[href^='mailto:']",
            "[data-field='email']", "#email", ".email-link"
        ]
        for selector in email_selectors:
            try:
                email_el = self.driver.find_element(By.CSS_SELECTOR, selector)
                email = email_el.get_attribute("value") or email_el.get_attribute("href").replace("mailto:", "") or email_el.text.strip()
                if '@' in email:
                    break
            except:
                continue
        
        # Phone selectors
        phone_selectors = [
            "[type='tel']", ".phone", ".contact-phone", "[data-field='phone']",
            "#phone", ".mobile", ".phone-number"
        ]
        for selector in phone_selectors:
            try:
                phone_el = self.driver.find_element(By.CSS_SELECTOR, selector)
                phone = phone_el.get_attribute("value") or phone_el.text.strip()
                if any(char.isdigit() for char in phone):
                    break
            except:
                continue
        
        # Fallback: search for text patterns
        if email == "Not found" or phone == "Not found":
            body_text = self.driver.find_element(By.TAG_NAME, "body").text
            lines = body_text.split('\n')
            for line in lines:
                stripped = line.strip()
                if '@' in stripped and email == "Not found":
                    email = stripped
                if any(char.isdigit() for char in stripped) and len(stripped) > 8 and phone == "Not found":
                    phone = stripped
        
        print(f"Extracted email: {email}, phone: {phone}")
        return email, phone

    def _download_resume(self, candidate_name):
        """Download the resume from the profile page"""
        download_selectors = [
            "button.download-resume", "a.download-resume", "button[title='Download Resume']",
            "a[href*='.pdf']", "a[href*='.doc']", "a[href*='resume']",
            ".download-btn", "#downloadResume", "a[href*='download']",
            "i[class*='download']", "span[class*='download']"
        ]
        
        downloaded = False
        for selector in download_selectors:
            try:
                download_btn = self.driver.find_element(By.CSS_SELECTOR, selector)
                download_btn.click()
                print(f"✅ Clicked download for {candidate_name}")
                time.sleep(5)  # Wait for download to complete
                downloaded = True
                break
            except:
                continue
        
        if not downloaded:
            print(f"⚠️ Could not find download button for {candidate_name}")
            return
        
        # Rename the latest downloaded file
        try:
            download_dir = os.path.abspath(self.resume_folder)
            files = [f for f in os.listdir(download_dir) if os.path.isfile(os.path.join(download_dir, f))]
            if files:
                latest_file = max([os.path.join(download_dir, f) for f in files], key=os.path.getctime)
                file_ext = os.path.splitext(latest_file)[1]
                new_name = os.path.join(download_dir, f"{candidate_name.replace(' ', '_')}_resume{file_ext}")
                os.rename(latest_file, new_name)
                print(f"✅ Renamed resume to {new_name}")
        except Exception as e:
            print(f"⚠️ Error renaming resume: {e}")
    
    def close_browser(self):
        """Close the browser"""
        if self.driver:
            self.driver.quit()
            print("🌐 Browser closed")

def main():
    # Your Ceipal ATS credentials - UPDATE THESE
    CEIPAL_URL = "https://talenthire.ceipal.com/signin?_gl=1*qngj62*_gcl_aw*R0NMLjE3NTc0Mjk3MjIuQ2owS0NRandvUF9GQmhERkFSSXNBTlBHMjRPOFFpTzk4d2tneERIOUd3RDdTME1Mcmt4dURDWm5IZWVJbnl0eWN0V19OcVlpZDhwb1Fsa2FBbXI3RUFMd193Y0I.*_gcl_au*MjkyNjQzOTY3LjE3NTczNDIzMDkuNDgxODE4NDk2LjE3NTczNTA3NDkuMTc1NzM1MDc0OA.."  # Replace with your actual Ceipal URL
    CEIPAL_USERNAME = "support@innosoul.com"              # Replace with your actual username
    CEIPAL_PASSWORD = "Db2@Admin1"              # Replace with your actual password
    
    # Search parameters
    skills = [
        "Java Full Stack Developer", "Spring Boot", "Spring", "Oracle", "Hibernate", "JPA",
        "Angular", "React", "RESTful APIs", "JSON", "NoSQL", "Git", "Jenkins",
        "Docker", "Kubernetes", "Maven", "TDD", "JWT", "Agile", "Scrum", "Kanban", "SDLC"
    ]
    
    # Choose search type (True for advanced Boolean, False for simple Boolean)
    USE_ADVANCED_BOOLEAN = True
    
    # Initialize automation
    ceipal_search = CeipalCandidateSearch()
    
    if not ceipal_search.setup_driver():
        print("❌ Failed to initialize browser automation")
        return
    
    try:
        # Login to Ceipal
        if ceipal_search.login_to_ceipal(CEIPAL_USERNAME, CEIPAL_PASSWORD, CEIPAL_URL):
            # Click Quick Links after login
            if ceipal_search.click_quick_links():
                # Navigate to Advanced Search
                if ceipal_search.navigate_to_advanced_search():
                    # Navigate to Dice job board
                    if ceipal_search.navigate_to_dice_job_board():
                        # Perform Dice search with Boolean syntax
                        if ceipal_search.perform_dice_search(skills, USE_ADVANCED_BOOLEAN):
                            # Extract results
                            candidates = ceipal_search.extract_search_results()
                            
                            # Display results summary in table
                            if candidates:
                                print("\n🎯 Extracted Candidate Details:")
                                print("{:<30} {:<30} {:<20}".format("Name", "Email", "Phone"))
                                print("=" * 80)
                                for candidate in candidates:
                                    print("{:<30} {:<30} {:<20}".format(
                                        candidate['name'][:28],
                                        candidate['email'][:28],
                                        candidate['phone'][:18]
                                    ))
                            else:
                                print("❌ No candidates found or extracted")
    
    except Exception as e:
        print(f"❌ An error occurred: {e}")
        traceback.print_exc()
    
    finally:
        # Keep browser open for review
        keep_open = input("\nKeep browser open for manual inspection? (y/n): ").lower().strip()
        if keep_open != 'y':
            ceipal_search.close_browser()
        else:
            print("Browser will remain open. You can manually inspect the page.")
            print("When done, close the browser window or press Ctrl+C in this terminal.")

if __name__ == "__main__":
    main()