import requests
from requests.auth import HTTPBasicAuth
import spacy
import time

def get_dice_access_token(client_id, client_secret):
    """
    Obtain an OAuth 2.0 access token from Dice.com using client credentials.
    Uses HTTP Basic Authentication for client credentials.
    """
    token_url = "https://secure.dice.com/oauth/token"
    data = {"grant_type": "client_credentials"}
    auth = HTTPBasicAuth(client_id, client_secret)
    
    try:
        response = requests.post(token_url, data=data, auth=auth)
        response.raise_for_status()
        token_data = response.json()
        print("✅ Access token obtained successfully!")
        return token_data['access_token']
    except requests.exceptions.RequestException as e:
        print(f"❌ Request failed: {e}")
        if response is not None:
            print(f"HTTP Status Code: {response.status_code}")
            print(f"Response Text: {response.text}")
        return None

def get_job_postings(access_token, query="software engineer", location=None, skills=None):
    """
    Fetch job postings from Dice.com API with optional filters.
    """
    url = "https://secure.dice.com/api/v1/jobs"  # Replace with actual endpoint
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Accept": "application/json"
    }
    params = {
        "q": query,
        "location": location,
        "skills": skills
    }
    # Remove None values from params
    params = {k: v for k, v in params.items() if v is not None}
    
    try:
        response = requests.get(url, headers=headers, params=params)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"❌ Failed to fetch job postings: {e}")
        if response is not None:
            print(f"HTTP Status Code: {response.status_code}")
            print(f"Response Text: {response.text}")
        return None

def search_resumes(access_token, skills, job_id=None, location=None, retries=3):
    """
    Search for candidate resumes on Dice.com based on skills, job ID, or location.
    Includes retry logic for rate limits.
    """
    url = "https://secure.dice.com/api/v1/resumes/search"  # Replace with actual endpoint
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Accept": "application/json"
    }
    params = {
        "skills": skills,
        "job_id": job_id,
        "location": location,
        "page": 1,
        "size": 10
    }
    # Remove None values from params
    params = {k: v for k, v in params.items() if v is not None}
    
    for attempt in range(retries):
        try:
            response = requests.get(url, headers=headers, params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
            if response.status_code == 429:  # Too Many Requests
                wait_time = 2 ** attempt
                print(f"Rate limit hit, retrying in {wait_time} seconds...")
                time.sleep(wait_time)
            else:
                print(f"❌ Failed to fetch resumes: {e}")
                print(f"HTTP Status Code: {response.status_code}")
                print(f"Response Text: {response.text}")
                return None
        except requests.exceptions.RequestException as e:
            print(f"❌ Failed to fetch resumes: {e}")
            return None
    print("❌ Max retries reached.")
    return None

def extract_skills_from_job_description(job_description):
    """
    Extract skills from a job description using spaCy.
    Requires: pip install spacy && python -m spacy download en_core_web_sm
    """
    try:
        nlp = spacy.load("en_core_web_sm")
    except OSError:
        print("❌ spaCy model 'en_core_web_sm' not found. Install it with: python -m spacy download en_core_web_sm")
        return []
    
    doc = nlp(job_description)
    # Predefined skill list (expand this based on your needs)
    skills = [
        "python", "java", "sql", "javascript", "machine learning", "aws", 
        "react", "node.js", "docker", "kubernetes", "typescript", "css", "html"
    ]
    extracted_skills = [token.text.lower() for token in doc if token.text.lower() in skills]
    return list(set(extracted_skills))

def main():
    # Your credentials
    client_id = "test-innosoul"
    client_secret = "bc7f2e7d-e3fd-404d-a968-a9781223adc0"
    
    # Get access token
    access_token = get_dice_access_token(client_id, client_secret)
    if not access_token:
        print("Failed to obtain access token.")
        return
    
    # Fetch job postings
    job_postings = get_job_postings(
        access_token,
        query="software engineer",
        location="remote",
        skills="python, java"
    )
    if job_postings:
        print("\n✅ Job Postings Retrieved:")
        for job in job_postings.get('results', []):  # Adjust based on actual response structure
            print(f"Title: {job.get('title', 'N/A')}, ID: {job.get('id', 'N/A')}, Skills: {job.get('skills', 'N/A')}")
    else:
        print("No job postings retrieved.")
    
    # Example job description
    job_description = """
    We are looking for a Software Engineer with experience in Python, Java, and SQL.
    Knowledge of machine learning and AWS is a plus. Familiarity with JavaScript and React is preferred.
    """
    
    # Extract skills from job description
    skills = extract_skills_from_job_description(job_description)
    if skills:
        print(f"\n✅ Extracted Skills: {', '.join(skills)}")
    else:
        print("\nNo skills extracted from job description.")
        return
    
    # Search resumes with extracted skills
    resumes = search_resumes(access_token, skills=",".join(skills), location="remote")
    if resumes:
        print("\n✅ Matching Resumes Retrieved:")
        for resume in resumes.get('results', []):  # Adjust based on actual response structure
            print(f"Candidate ID: {resume.get('id', 'N/A')}, Skills: {resume.get('skills', 'N/A')}")
    else:
        print("No resumes retrieved.")

if __name__ == "__main__":
    main()