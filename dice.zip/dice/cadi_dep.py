import requests
from requests.auth import HTTPBasicAuth
import base64

# ========== CONFIGURATION ==========
client_id = "test-innosoul"
client_secret = "bc7f2e7d-e3fd-404d-a968-a9781223adc0"
token_url = "https://secure.dice.com/oauth/token"
base_url = "https://employer-api.dice.com/v0.1/applications/{NC-777857}"
job_code = "NC-777857"
# ===================================


def get_access_token():
    """Request an access token using client credentials with Basic Auth"""
    print("🔑 Requesting access token...")
    
    data = {
        "grant_type": "client_credentials"
    }

    # Method 1: Using HTTP Basic Authentication (recommended)
    try:
        auth = HTTPBasicAuth(client_id, client_secret)
        
        headers = {
            "Content-Type": "application/x-www-form-urlencoded"
        }

        print(f"📤 Sending token request to: {token_url}")
        response = requests.post(token_url, data=data, headers=headers, auth=auth, timeout=30)
        
        print(f"📥 Response status: {response.status_code}")
        
        if response.status_code == 200:
            token_data = response.json()
            access_token = token_data.get("access_token")
            if access_token:
                print("✅ Access token obtained successfully!")
                print(f"   Token type: {token_data.get('token_type', 'N/A')}")
                print(f"   Expires in: {token_data.get('expires_in', 'N/A')} seconds")
                return access_token
            else:
                print("❌ No access token in response")
                return None
        else:
            print(f"❌ Failed to get access token: {response.status_code}")
            print(f"   Response: {response.text}")
            return None
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Request failed: {e}")
        return None


def get_access_token_manual():
    """Alternative method with manual Basic Auth header"""
    print("🔑 Requesting access token (manual method)...")
    
    data = {
        "grant_type": "client_credentials"
    }
    
    # Manually create Basic Auth header
    credentials = f"{client_id}:{client_secret}"
    encoded_credentials = base64.b64encode(credentials.encode()).decode()
    
    headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        "Authorization": f"Basic {encoded_credentials}"
    }

    try:
        print(f"📤 Sending token request to: {token_url}")
        response = requests.post(token_url, data=data, headers=headers, timeout=30)
        
        print(f"📥 Response status: {response.status_code}")
        
        if response.status_code == 200:
            token_data = response.json()
            access_token = token_data.get("access_token")
            if access_token:
                print("✅ Access token obtained successfully!")
                return access_token
            else:
                print("❌ No access token in response")
                return None
        else:
            print(f"❌ Failed to get access token: {response.status_code}")
            print(f"   Response: {response.text}")
            return None
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Request failed: {e}")
        return None


def get_job_submissions(access_token, job_code):
    """Fetch submissions for the given job code"""
    print(f"\n📋 Fetching submissions for job: {job_code}")
    
    url = f"{base_url}/jobs/{job_code}/submissions"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
        "Accept": "application/json"
    }

    try:
        print(f"📤 Sending request to: {url}")
        response = requests.get(url, headers=headers, timeout=30)
        
        print(f"📥 Response status: {response.status_code}")
        
        if response.status_code == 200:
            submissions_data = response.json()
            print("✅ Submissions fetched successfully!")
            print(f"📊 Response: {submissions_data}")
            return submissions_data
        elif response.status_code == 401:
            print("❌ Unauthorized - Invalid or expired access token")
            print(f"   Response: {response.text}")
        elif response.status_code == 404:
            print("❌ Not found - Job code may not exist or no submissions available")
            print(f"   Response: {response.text}")
        else:
            print(f"❌ Error fetching submissions ({response.status_code}): {response.text}")
        return None
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Request failed: {e}")
        return None
    except ValueError as e:
        print(f"❌ JSON parsing error: {e}")
        print(f"   Response text: {response.text}")
        return None


def test_api_connection(access_token):
    """Test the API connection with a simple request"""
    print(f"\n🧪 Testing API connection...")
    
    url = f"{base_url}/jobs"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }

    try:
        # Try to get jobs list to test the connection
        response = requests.get(url, headers=headers, timeout=30)
        print(f"🧪 Test request status: {response.status_code}")
        
        if response.status_code == 200:
            print("✅ API connection test successful!")
            return True
        else:
            print(f"⚠️  API connection test returned: {response.status_code}")
            print(f"   Response: {response.text}")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"❌ API connection test failed: {e}")
        return False


if __name__ == "__main__":
    print("🚀 Starting DICE API Client...")
    print("=" * 50)
    
    # Try the main method first
    token = get_access_token()
    
    # If main method fails, try manual method
    if not token:
        print("\n🔄 Trying alternative authentication method...")
        token = get_access_token_manual()
    
    if token:
        # Test the API connection first
        if test_api_connection(token):
            # Then fetch submissions
            submissions = get_job_submissions(token, job_code)
            
            if submissions:
                print("\n🎉 Success! Process completed.")
            else:
                print("\n💡 No submissions data retrieved.")
        else:
            print("\n❌ API connection test failed. Check your credentials and network.")
    else:
        print("\n💥 Failed to obtain access token. Please check your configuration.")
    
    print("=" * 50)
    print("🏁 Process completed.")