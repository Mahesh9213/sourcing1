import requests
import base64

# ========== CONFIGURATION ==========
client_id = "test-innosoul"
client_secret = "bc7f2e7d-e3fd-404d-a968-a9781223adc0"
token_url = "https://secure.dice.com/oauth/token"
base_url = "https://employer-api.dice.com/v0.1/applications/{NC-777857}"
job_code = "NC-777857"
# ===================================


def get_access_token():
    """Request an access token using client credentials via Basic Auth"""
    # Encode client_id:client_secret in Base64
    credentials = f"{client_id}:{client_secret}"
    encoded_credentials = base64.b64encode(credentials.encode()).decode()

    headers = {
        "Authorization": f"Basic {encoded_credentials}",
        "Content-Type": "application/x-www-form-urlencoded"
    }

    data = {
        "grant_type": "client_credentials"
    }

    response = requests.post(token_url, headers=headers, data=data)

    if response.status_code == 200:
        token_data = response.json()
        print("✅ Access token generated successfully")
        return token_data["access_token"]
    else:
        print("❌ Failed to get access token:", response.status_code, response.text)
        return None


def get_job_submissions(access_token, job_code):
    """Fetch submissions for the given job code"""
    url = f"{base_url}/jobs/{job_code}/submissions"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }

    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        print("✅ Submissions fetched successfully:")
        print(response.json())
    else:
        print(f"❌ Error fetching submissions ({response.status_code}): {response.text}")


if __name__ == "__main__":
    token = get_access_token()
    if token:
        get_job_submissions(token, job_code)
