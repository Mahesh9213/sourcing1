import requests
from requests.auth import HTTPBasicAuth
import base64

def get_dice_access_token(client_id, client_secret):
    """
    Obtain an OAuth 2.0 access token from Dice.com using client credentials.
    Uses HTTP Basic Authentication for client credentials.
    """
    token_url = "https://secure.dice.com/oauth/token"
    data = {
        "grant_type": "client_credentials"
    }
    auth = HTTPBasicAuth(client_id, client_secret)
    
    try:
        response = requests.post(token_url, data=data, auth=auth)
        response.raise_for_status()  # Raises an HTTPError for bad responses (4xx or 5xx)
        token_data = response.json()
        print("✅ Access token obtained successfully!")
        return token_data['access_token']
    except requests.exceptions.RequestException as e:
        print(f"❌ Request failed: {e}")
        if response is not None:
            print(f"HTTP Status Code: {response.status_code}")
            print(f"Response Text: {response.text}")
        return None

# Your credentials
client_id = "test-innosoul"
client_secret = "bc7f2e7d-e3fd-404d-a968-a9781223adc0"

# Attempt to get the token
access_token = get_dice_access_token(client_id, client_secret)
if access_token:
    print(f"Access Token: {access_token}")
else:
    print("Failed to obtain access token.")