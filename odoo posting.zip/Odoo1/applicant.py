import requests
import json
import xmlrpc.client
import os
import base64


# -------------------------
# Odoo Connector
# -------------------------
class OdooConnector:
    def __init__(self, url: str, db: str, username: str, password: str):
        self.url = url
        self.db = db
        self.username = username
        self.password = password
        self.uid = None
        self.models = None
        self._connect()

    def _connect(self):
        try:
            common = xmlrpc.client.ServerProxy(f"{self.url}/xmlrpc/2/common")
            self.uid = common.authenticate(self.db, self.username, self.password, {})
            if not self.uid:
                raise Exception("Odoo authentication failed. Check credentials.")
            self.models = xmlrpc.client.ServerProxy(f"{self.url}/xmlrpc/2/object")
            print(f"✅ Connected to Odoo (UID: {self.uid})")
        except Exception as e:
            print(f"❌ Odoo connection error: {e}")
            raise

    def create_applicant(
        self,
        name: str,
        job_title: str,
        skills: str,
        resume_path: str,
        email: str = None,
        phone: str = None,
    ):
        """Create Partner → Applicant + Resume in Odoo"""

        try:
            # -------------------------
            # Step 1: Create Partner (store contact info)
            # -------------------------
            partner_vals = {"name": name}
            if email:
                partner_vals["email"] = email
            if phone:
                partner_vals["phone"] = phone

            partner_id = self.models.execute_kw(
                self.db,
                self.uid,
                self.password,
                "res.partner",
                "create",
                [partner_vals],
            )
            print(f"👤 Partner created (ID: {partner_id})")

            # -------------------------
            # Step 2: Find or Create Job by Title
            # -------------------------
            job_id = False
            if job_title:
                jobs = self.models.execute_kw(
                    self.db,
                    self.uid,
                    self.password,
                    "hr.job",
                    "search_read",
                    [[["name", "=", job_title]]],
                    {"fields": ["id"], "limit": 1},
                )
                if jobs:
                    job_id = jobs[0]["id"]
                else:
                    job_id = self.models.execute_kw(
                        self.db,
                        self.uid,
                        self.password,
                        "hr.job",
                        "create",
                        [{"name": job_title}],
                    )
                    print(f"📌 Job Position created: {job_title} (ID: {job_id})")

            # -------------------------
            # Step 3: Create Applicant linked to Partner + Job
            # -------------------------
            applicant_vals = {
                "partner_name": name,
                "partner_id": partner_id,  # ✅ link directly to partner
                "x_resume_summary": f"Skills: {skills}",
                "job_id": job_id or False,
            }
            if email:
                applicant_vals["email_from"] = email
            if phone:
                applicant_vals["partner_phone"] = phone

            applicant_id = self.models.execute_kw(
                self.db,
                self.uid,
                self.password,
                "hr.applicant",
                "create",
                [applicant_vals],
            )
            print(f"📌 Applicant created (ID: {applicant_id}) linked to Job {job_title}")

            # -------------------------
            # Step 4: Attach Resume (only if valid)
            # -------------------------
            if resume_path and os.path.exists(resume_path):
                if os.path.getsize(resume_path) < 1024:  # skip tiny/corrupt files
                    print(f"⚠️ Resume too small/corrupted: {resume_path}")
                    return applicant_id

                with open(resume_path, "rb") as f:
                    resume_data = base64.b64encode(f.read()).decode("utf-8")

                attachment_vals = {
                    "name": os.path.basename(resume_path),
                    "res_model": "hr.applicant",
                    "res_id": applicant_id,
                    "datas": resume_data,
                    "mimetype": "application/pdf",
                }

                attachment_id = self.models.execute_kw(
                    self.db,
                    self.uid,
                    self.password,
                    "ir.attachment",
                    "create",
                    [attachment_vals],
                )
                print(f"📎 Resume attached (ID: {attachment_id})")

            return applicant_id

        except Exception as e:
            print(f"❌ Error pushing applicant {name} to Odoo: {e}")
            return None


# -------------------------
# Ceipal API
# -------------------------
class CeipalAPI:
    def __init__(self):
        self.base_url = "https://api.ceipal.com/v1"
        self.auth_token = None

    def authenticate(self, email: str, password: str, api_key: str) -> bool:
        url = f"{self.base_url}/createAuthtoken"
        payload = {"email": email, "password": password, "api_key": api_key}
        headers = {"Content-Type": "application/json", "Accept": "application/json"}
        try:
            response = requests.post(url, headers=headers, json=payload, timeout=30)
            response.raise_for_status()
            data = response.json()
            self.auth_token = data.get("access_token")
            return self.auth_token is not None
        except Exception as e:
            print(f"❌ Authentication error: {e}")
            return False

    def get_applicants(self, page: int = 1):
        if not self.auth_token:
            print("❌ Not authenticated. Please authenticate first.")
            return None

        url = f"{self.base_url}/getApplicantsList"
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": f"Bearer {self.auth_token}",
        }
        params = {"page": page}
        try:
            response = requests.get(url, headers=headers, params=params, timeout=30)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            print(f"❌ Error fetching applicants: {e}")
            return None

    def download_resume(
        self,
        resume_url: str,
        applicant_name: str,
        job_title: str = "",
        download_dir: str = "resumes",
    ):
        if not resume_url or resume_url == "N/A":
            print(f"No resume URL for {applicant_name}")
            return None

        os.makedirs(download_dir, exist_ok=True)

        clean_name = "".join(
            c for c in applicant_name if c.isalnum() or c in (" ", "-", "_")
        ).rstrip()
        clean_job = "".join(
            c for c in job_title if c.isalnum() or c in (" ", "-", "_")
        ).rstrip()
        filename = (
            f"{clean_name} - {clean_job}.pdf" if clean_job else f"{clean_name}.pdf"
        )
        filepath = os.path.join(download_dir, filename)

        headers = {"Authorization": f"Bearer {self.auth_token}"}
        try:
            response = requests.get(resume_url, headers=headers, timeout=30)
            response.raise_for_status()
            with open(filepath, "wb") as f:
                f.write(response.content)
            print(f"📄 Resume saved: {filepath}")
            return filepath
        except Exception as e:
            print(f"❌ Error downloading resume for {applicant_name}: {e}")
            return None


# -------------------------
# Main process
# -------------------------
def main():
    # Ceipal credentials
    CREDENTIALS = {
        "email": "support@innosoul.com",
        "password": "Db2@Admin1",
        "api_key": "226113748caee4447d14c2ddc0fbd12f0de8153d90b52547f2",
    }

    # Odoo credentials
    ODOO_CONF = {
        "url": "http://84.247.136.24:8069",
        "db": "mydb",
        "username": "admin",
        "password": "79NM46eRqDv)w^q^",
    }

    print("=== Ceipal → Odoo Resume Integration ===")

    # Init Ceipal API
    api = CeipalAPI()
    print("Authenticating to Ceipal...")
    if not api.authenticate(**CREDENTIALS):
        print("❌ Ceipal authentication failed")
        return
    print("✅ Ceipal authentication successful")

    # Init Odoo
    try:
        odoo = OdooConnector(**ODOO_CONF)
    except Exception:
        return

    # Fetch applicants
    applicants_data = api.get_applicants()
    if not applicants_data or "results" not in applicants_data:
        print("No applicants found.")
        return

    applicants = applicants_data["results"]
    print(f"Found {len(applicants)} applicants in Ceipal")

    # Process applicants
    for applicant in applicants:
        name = f"{applicant.get('firstname', '')} {applicant.get('lastname', '')}".strip()
        job_title = applicant.get("job_title", "Unknown")
        skills = applicant.get("skills", "")
        email = applicant.get("email", None)
        phone = applicant.get("phone", None)
        resume_url = applicant.get("resume_path")

        print(f"\n➡ Processing {name} ({job_title})")

        resume_path = api.download_resume(resume_url, name, job_title)
        if resume_path:
            odoo.create_applicant(name, job_title, skills, resume_path, email, phone)


if __name__ == "__main__":
    main()
