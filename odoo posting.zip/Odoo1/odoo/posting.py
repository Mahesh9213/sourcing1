#!/usr/bin/env python3
import re
import json
import time
import xmlrpc.client


# -------------------------
# Load Config
# -------------------------
def load_config(path="config.json"):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


# -------------------------
# Split postings
# -------------------------
def split_postings(text):
    blocks = re.split(r"(?m)^Job ID\s*:", text)
    result = []
    for b in blocks:
        if b.strip():
            result.append("Job ID:" + b.strip())
    return result


# -------------------------
# Field Extractors
# -------------------------
def extract_line(label, text):
    """Extract EXACT one line field"""
    pattern = rf"{label}\s*:\s*(.+)"
    m = re.search(pattern, text)
    if m:
        return m.group(1).strip()
    return ""


def extract_skills(text):
    """Extract skills block only"""
    m = re.search(r"Skills\s*:\s*([\s\S]*?)(?=\n[A-Z][a-zA-Z ]+:\s|\Z)", text)
    return m.group(1).strip() if m else ""


def extract_description(text):
    """Extract only description block"""
    m = re.search(r"Description\s*:\s*([\s\S]*)", text)
    return m.group(1).strip() if m else ""


# -------------------------
# Parse Posting
# -------------------------
def parse_posting(text):
    job_id = extract_line("Job ID", text)
    location = extract_line("Location", text)
    duration = extract_line("Duration", text)
    positions = extract_line("Position", text) or extract_line("Positions", text)
    skills = extract_skills(text)
    description = extract_description(text)

    # Title = first non-empty line after Job ID
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    title = ""
    for l in lines[1:5]:
        if not re.match(r"^(Location|Duration|Skills|Position|Positions):", l):
            title = l
            break

    return {
        "name": title,
        "x_job_id": job_id,
        "x_location": location,
        "x_duration": duration,
        "x_positions": positions,
        "x_skills": skills,
        "x_description": description
    }


# -------------------------
# Odoo Connect
# -------------------------
def xmlrpc_common(url):
    return xmlrpc.client.ServerProxy(f"{url}/xmlrpc/2/common")


def xmlrpc_models(url):
    return xmlrpc.client.ServerProxy(f"{url}/xmlrpc/2/object")


def authenticate(url, db, username, password):
    return xmlrpc_common(url).authenticate(db, username, password, {})


# -------------------------
# Update or Create
# -------------------------
def update_or_create(models, db, uid, password, data):
    jid = data["x_job_id"]

    exist = models.execute_kw(
        db, uid, password,
        "hr.job", "search",
        [[["x_job_id", "=", jid]]]
    )

    if exist:
        models.execute_kw(
            db, uid, password,
            "hr.job", "write",
            [exist, data]
        )
        print("✔ UPDATED:", jid)
        return

    new_id = models.execute_kw(
        db, uid, password,
        "hr.job", "create",
        [data]
    )
    print("✔ CREATED:", new_id, jid)


# -------------------------
# MAIN
# -------------------------
def main():

    cfg = load_config()
    url = cfg["odoo_url"]
    db = cfg["odoo_db"]
    user = cfg["odoo_username"]
    pwd = cfg["odoo_password"]

    uid = authenticate(url, db, user, pwd)
    if not uid:
        print("❌ Login failed")
        return

    print("✔ Logged in:", uid)
    models = xmlrpc_models(url)

    # Read jobs file
    with open(cfg["jobs_file"], "r", encoding="utf-8") as f:
        content = f.read()

    postings = split_postings(content)
    print("Found postings:", len(postings))

    for post in postings:
        data = parse_posting(post)
        update_or_create(models, db, uid, pwd, data)
        time.sleep(0.1)

    print("✔ Done updating")


if __name__ == "__main__":
    main()
